from asyncio.windows_events import NULL
from zoneinfo import available_timezones
from django.http import HttpResponse
from django.db.models import Avg, Count, Min, Sum
# from django.contrib.gis.utils import GeoIP

from rest_framework import viewsets, status, generics
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated, AllowAny

from rest_framework.authtoken.models import Token
from rest_framework.authtoken.serializers import AuthTokenSerializer

from django.contrib.auth.models import User
from .models import CurrencyBalanceHistory, UserBalance, UserBalanceHistory
from .serializers import UserBalanceSerializer

from sentry_sdk import capture_exception
import time

# g = GeoIP()
# def get_typeActivityID(id):
#     try:
#         return TypeActivity.objects.get(id=id)
#     except TypeActivity.DoesNotExist:
#         return HttpResponse(status=status.HTTP_404_NOT_FOUND)

# def get_bankID(id):
#     try:
#         return Bank.objects.get(id=id)
#     except Bank.DoesNotExist:
#         return HttpResponse(status=status.HTTP_404_NOT_FOUND)

# def get_bankbalanceID(id):
#     try:
#         return BankBalance.objects.get(id=id)
#     except BankBalance.DoesNotExist:
#         return HttpResponse(status=status.HTTP_404_NOT_FOUND)

# def get_bankbalance(bankid):
#     try:
#         return BankBalance.objects.get(bank=bankid)
#     except BankBalance.DoesNotExist:
#         return HttpResponse(status=status.HTTP_404_NOT_FOUND)

# def get_userbalance(userid, bankid):
#     try:
#         return UserBalance.objects.get(user=userid, bank=bankid)
#     except UserBalance.DoesNotExist:
#         balance = UserBalance(bank=get_bankID(bankid), user=get_userID(userid), balance=0, balance_achieve=0)
#         balance.save()
#         return UserBalance.objects.get(user=userid, bank=bankid)
#         # return HttpResponse(status=status.HTTP_404_NOT_FOUND)

# def get_userbalanceID(id):
#     try:
#         return UserBalance.objects.get(id=id)
#     except UserBalance.DoesNotExist:
#         return HttpResponse(status=status.HTTP_404_NOT_FOUND)

# def get_userbalancehistory(id):
#     try:
#         return UserBalanceHistory.objects.get(id=id)
#     except UserBalanceHistory.DoesNotExist:
#         return HttpResponse(status=status.HTTP_404_NOT_FOUND)

def get_balance(userid, currency):
    try:
        userbalance = UserBalance.objects.get(user=userid)
        return userbalance
    except UserBalance.DoesNotExist:
        balance = UserBalance.objects.create(user=get_user_by_id(userid), currency=currency)
        return balance


def get_user_by_id(userid):
    try:
        return User.objects.get(id=userid)
    except User.DoesNotExist:
        return NULL

def get_user_by_name(username):
    try:
        return User.objects.get(username=username)
    except User.DoesNotExist:
        return NULL

def get_transaction(id):
    try:
        return UserBalanceHistory.objects.get(id = id)
    except UserBalanceHistory.DoesNotExist:
        return NULL

# get current fiat balance
class GetBalance(APIView):
    authentication_classes = [TokenAuthentication, ]
    permission_classes = [IsAuthenticated, ]
    def post(self, request):
        try:
            balance = get_balance(request.user.id, request.data['currency'])
            serializer = UserBalanceSerializer(balance)
            response = {"data": serializer.data}
            return Response(response, status=status.HTTP_200_OK, headers="")
        except Exception as e:
            capture_exception(e)
            return Response("Error", status = status.HTTP_400_BAD_REQUEST, headers="")

# # bank
# class BankApiSetView(APIView):
#     authentication_classes = [TokenAuthentication, ]
#     permission_classes = [IsAuthenticated, ]
#     def get(self, request):
#         banks = Bank.objects.all()
#         serializer = BankSerializer(banks, many=True)
#         return Response(serializer.data)

# #user bank
# class UserBankApiSetView(APIView):
#     authentication_classes = [TokenAuthentication, ]
#     permission_classes = [IsAuthenticated, ]
#     def get(self, request, userid):
#         banks = UserBalance.objects.all().filter(user=userid)
#         serializer = UserBalanceSerializer(banks, many=True)
#         return Response(serializer.data)

# #user balance history
# class UserBalanceHistoryApiSetView(APIView):
#     authentication_classes = [TokenAuthentication, ]
#     permission_classes = [IsAuthenticated, ]
#     def get(self, request, userid):
#         userbalanceshistory = UserBalance.objects.all().filter(user=userid)
#         serializer = UserBalanceSerializer(userbalanceshistory, many=True)
#         return Response(serializer.data)

# add fund to account with stripe
class TopUpFromStripe(APIView):
    authentication_classes = [TokenAuthentication, ]
    permission_classes = [IsAuthenticated, ]
    def post(self, request):
        # currency
        # amount
        # stripe_secret_key
        
        try:
            currency, stripe_secret_key, amount = request.data['currency'], request.data['stripe_secret_key'], request.data['amount']
            fee = amount * 0.015 + 0.3

            if amount < 5:
                return Response({'message': 'Amount must be over 5'}, status = status.HTTP_400_BAD_REQUEST, headers="")
            if amount > 500:
                return Response({'message': 'Amount must be less 500'}, status = status.HTTP_400_BAD_REQUEST, headers="")

            balance = get_balance(request.user.id, currency)

            # save new transaction
            new_transaction = UserBalanceHistory(
                currency = currency,
                sender = User.objects.get(id = 1),
                recipient = request.user,
                amount = amount,
                time = int(time.time()),
                fee = fee,
            )
            new_transaction.save()

            # add user's current balance
            balance.current_balance = balance.current_balance + amount - fee
            balance.save()
            
            response = {'data': new_transaction.id}
            return Response(response, status=status.HTTP_200_OK, headers="")
        except Exception as e:
            capture_exception(e)
            return Response("Error", status = status.HTTP_400_BAD_REQUEST, headers="")

# confirm top up and make fund available
class ConfirmTopUpTransaction(APIView):
    # authentication_classes = [TokenAuthentication, ]
    # permission_classes = [IsAuthenticated, ]
    def post(self, request):
        # transaction
        
        try:
            transaction = get_transaction(request.data['transaction'])

            if transaction == NULL:
                return Response({'message': 'Invalid transaction'}, status = status.HTTP_400_BAD_REQUEST, headers="")

            # confirm transaction
            transaction.confirmed = True
            transaction.save()

            # remove current balance and add available balance
            real_amount = transaction.amount - transaction.fee
            user_balance = get_balance(transaction.recipient, transaction.currency)
            user_balance.available_balance = user_balance.available_balance + real_amount
            user_balance.current_balance = user_balance.current_balance - real_amount
            if user_balance.enabled == False and user_balance.available_balance >= 5:
                user_balance.enabled = True
            user_balance.save()

            response = {'data': 'success'}
            return Response(response, status=status.HTTP_200_OK, headers="")
        except Exception as e:
            capture_exception(e)
            return Response("Error", status = status.HTTP_400_BAD_REQUEST, headers="")

# user transfer money
class TransferMoney(APIView):
    authentication_classes = [TokenAuthentication, ]
    permission_classes = [IsAuthenticated, ]
    def post(self, request):
        # recipient
        # currency
        # amount
        
        try:
            recipient, currency, amount = get_user_by_name(request.data['recipient']), request.data['currency'], request.data['amount']

            if recipient == NULL:
                return Response("Invalid recipient", status = status.HTTP_400_BAD_REQUEST, headers="")

            sender_balance, recipient_balance = get_balance(request.user.id, currency), get_balance(recipient.id, currency)
            if sender_balance.enabled == False or sender_balance.closed == False:
                return Response("User's wallet is diabled", status = status.HTTP_400_BAD_REQUEST, headers="")
            if sender_balance.available_balance < amount:
                return Response("Transfer amount is over balance", status = status.HTTP_400_BAD_REQUEST, headers="")
            if recipient_balance.enabled == False or recipient_balance.closed == False:
                return Response("Recipient's wallet is diabled", status = status.HTTP_400_BAD_REQUEST, headers="")

            # save new transaction
            new_transaction = UserBalanceHistory(
                currency = currency,
                sender = request.user,
                recipient = recipient,
                amount = amount,
                time = int(time.time()),
                fee = 0,
                confirmed = True
            )
            new_transaction.save()

            # add recipient's balance
            recipient_balance.available_balance += amount
            
            response = {"data": 0}
            return Response(response, status=status.HTTP_200_OK, headers="")
        except Exception as e:
            capture_exception(e)
            return Response("Error", status = status.HTTP_400_BAD_REQUEST, headers="")

# class ConfirmUserTopUp(APIView):
#     # authentication_classes = [TokenAuthentication, ]
#     # permission_classes = [IsAuthenticated, ]
#     def get(self, request, userbalancehistoryid):
#         userbalancehistory = get_userbalancehistory(userbalancehistoryid)
#         userbalance = get_userbalanceID(userbalancehistory.user_balance_id)
#         bank = get_bankID(userbalance.bank_id)
#         bankbalance = get_bankbalance(bank.id)


#         # Add uang ke user balance
#         changeBalance = userbalancehistory.balance_after-userbalancehistory.balance_before
#         newBalanceUser=0
#         if(userbalance.balance == userbalancehistory.balance_before):
#             newBalanceUser = userbalancehistory.balance_after
#         else:
#             newBalanceUser = userbalance.balance+changeBalance
            
#         userbalance.balance=newBalanceUser
#         userbalance.save()
        
        
#         # Add uang ke bank balance history
#         newBankBalance = bankbalance.balance + changeBalance
        
#         b = BankBalanceHistory(bank_balance=bankbalance, balance_before=bankbalance.balance, balance_after=newBankBalance, activity=userbalancehistory.activity, typeActivity=userbalancehistory.typeActivity, ip = userbalancehistory.ip, location=userbalancehistory.location, user_agent=userbalancehistory.user_agent, author=userbalancehistory.author)
#         b.save()
        
#         bankbalance.balance=newBankBalance
#         bankbalance.save()
        
#         # Confim uang Top Up
#         userbalancehistory.confirm = True
#         userbalancehistory.save()

#         totalbalance = get_totalbalance(userbalance.user_id)
#         response = {"data": totalbalance}
#         return Response(response, status=status.HTTP_200_OK, headers="")



# # user transfer uang
# class UserTransferMoney(APIView):
#     authentication_classes = [TokenAuthentication, ]
#     permission_classes = [IsAuthenticated, ]
#     def post(self, request):
#         # User
#         # user
#         # bank
#         # user_agent -> send to
#         # balance_after -> amount
#         # send_to_bank

#         userbalance = get_userbalance(request.data['user'], request.data['bank'])
#         userSendTo = get_user(request.data['user_agent'])

#         senderBalanceAfter=userbalance.balance-int(request.data['balance_after'])
#         senderActivity=UserBalanceHistory(user_balance=userbalance, balance_before=userbalance.balance, balance_after= senderBalanceAfter, activity='Transfer', typeActivity=get_typeActivityID(1), ip=request.META['REMOTE_ADDR'], location='', user_agent='', author='', send_to=userSendTo, send_to_bank=get_bankID(request.data['send_to_bank']), confirm=True)
#         senderActivity.save()
        
#         userbalance.balance=senderBalanceAfter
#         userbalance.save()

#         receiverbalance=get_userbalance(userSendTo.id, request.data['send_to_bank'])

#         receiverbalanceAfter=receiverbalance.balance+int(request.data['balance_after'])
#         receiverActivity=UserBalanceHistory(user_balance=receiverbalance, balance_before=receiverbalance.balance, balance_after= receiverbalanceAfter, activity='Receive Money', typeActivity=get_typeActivityID(3), ip=request.META['REMOTE_ADDR'], location='', user_agent='', author='', send_to=get_userID(request.data['user']), send_to_bank=get_bankID(request.data['bank']), confirm=True)
#         receiverActivity.save()
        
#         receiverbalance.balance=receiverbalanceAfter
#         receiverbalance.save()

#         # Bank
#         bankbalance = get_bankbalance(request.data['bank'])
#         newBankBalance = bankbalance.balance - int(request.data['balance_after'])
        
#         b = BankBalanceHistory(bank_balance=bankbalance, balance_before=bankbalance.balance, balance_after=newBankBalance, activity='Transfer', typeActivity=get_typeActivityID(1), ip=request.META['REMOTE_ADDR'], location='', user_agent='', author='')
#         b.save()
        
#         bankbalance.balance=newBankBalance
#         bankbalance.save()


#         bankReceiveBalance = get_bankbalance(request.data['send_to_bank'])
#         newBankReceiveBalance = bankReceiveBalance.balance + int(request.data['balance_after'])
        
#         bReceive = BankBalanceHistory(bank_balance=bankReceiveBalance, balance_before=bankReceiveBalance.balance, balance_after=newBankReceiveBalance, activity='Receive Money', typeActivity=get_typeActivityID(3), ip=request.META['REMOTE_ADDR'], location='', user_agent='', author='')
#         bReceive.save()
        
#         bankReceiveBalance.balance=newBankReceiveBalance
#         bankReceiveBalance.save()

#         totalbalance = get_totalbalance(request.data['user'])
#         response = {"data": totalbalance}
#         return Response(response, status=status.HTTP_200_OK, headers="")

        

