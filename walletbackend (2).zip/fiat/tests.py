from django.urls import path, reverse, include, resolve
from django.test import SimpleTestCase
from rest_framework.test import APITestCase, APIClient
from rest_framework.authtoken.models import Token
from rest_framework import status
from django.contrib.auth.models import User
from rest_framework.views import APIView
from .views import GetBalance, TopUpFromStripe, ConfirmTopUpTransaction

class ApiUrlsTests(SimpleTestCase):
    def test_get_balance_is_resolved(self):
        url = reverse('fiat_get_balance')
        self.assertEquals(resolve(url).func.view_class, GetBalance)

    def test_topup_is_resolved(self):
        url = reverse('fiat_topup')
        self.assertEquals(resolve(url).func.view_class, TopUpFromStripe)

    def test_confirm_topup_is_resolved(self):
        url = reverse('fiat_confirm_topup')
        self.assertEquals(resolve(url).func.view_class, ConfirmTopUpTransaction)

class GetBalanceTests(APITestCase):
    get_balance_url = reverse('fiat_get_balance')

    def setUp(self):
        self.user = User.objects.create_user(
            username='admin', password='admin')
        self.token = Token.objects.create(user=self.user)
        self.client.credentials(HTTP_AUTHORIZATION='Token ' + self.token.key)

    def test_unathenticated(self):
        self.client.force_authenticate(user=None, token=None)
        response = self.client.post(self.get_balance_url)
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_get_fiat_balance(self):
        data = {
            'currency': 'USD'
        }
        response = self.client.post(self.get_balance_url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)

class TopupTests(APITestCase):
    get_balance_url = reverse('fiat_get_balance')
    topup_url = reverse('fiat_topup')

    def setUp(self):
        User.objects.create_user(username='admin', password='admin')

        self.user = User.objects.create_user(
            username='user1', password='user1')
        self.token = Token.objects.create(user=self.user)
        self.client.credentials(HTTP_AUTHORIZATION='Token ' + self.token.key)

        self.balance = self.client.post(self.get_balance_url, {'currency': 'USD'}, format='json').data['data']

    def test_unathenticated(self):
        self.client.force_authenticate(user=None, token=None)
        response = self.client.post(self.topup_url)
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
    
    def test_topup_less_5(self):
        data = {
            'currency': 'USD',
            'stripe_secret_key': '',
            'amount': 4,
        }
        response = self.client.post(self.topup_url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
    
    def test_topup_over_500(self):
        data = {
            'currency': 'USD',
            'stripe_secret_key': '',
            'amount': 501,
        }
        response = self.client.post(self.topup_url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
    
    def test_topup(self):
        transfer_amount = 10
        data = {
            'currency': 'USD',
            'stripe_secret_key': '',
            'amount': transfer_amount,
        }
        response = self.client.post(self.topup_url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        new_balance = self.client.post(self.get_balance_url, {'currency': 'USD'}, format='json').data['data']
        self.assertEqual(round(new_balance['current_balance'], 5), round(transfer_amount - transfer_amount * 0.015 - 0.3, 5))

class ConfirmTopupTests(APITestCase):
    get_balance_url = reverse('fiat_get_balance')
    topup_url = reverse('fiat_topup')
    confirm_topup_url = reverse('fiat_confirm_topup')

    def setUp(self):
        User.objects.create_user(username='admin', password='admin')

        self.user = User.objects.create_user(
            username='user1', password='user1')
        self.token = Token.objects.create(user=self.user)
        self.client.credentials(HTTP_AUTHORIZATION='Token ' + self.token.key)

        self.transfer_amount = 10
        data = {
            'currency': 'USD',
            'stripe_secret_key': '',
            'amount': self.transfer_amount,
        }
        self.client.post(self.topup_url, data, format='json')
    
    def test_invalid(self):
        data = {
            'transaction': 2
        }
        response = self.client.post(self.confirm_topup_url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_confirm(self):
        data = {
            'transaction': 1
        }
        response = self.client.post(self.confirm_topup_url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        new_balance = self.client.post(self.get_balance_url, {'currency': 'USD'}, format='json').data['data']
        self.assertEqual(round(new_balance['available_balance'], 5), round(self.transfer_amount - self.transfer_amount * 0.015 - 0.3, 5))
        self.assertEqual(new_balance['current_balance'], 0)