from django.urls import path, include
from .views import GetBalance, TopUpFromStripe, ConfirmTopUpTransaction, TransferMoney

urlpatterns = [
    path('get_balance', GetBalance.as_view(), name = 'fiat_get_balance'),
    # path('bankuser/<int:userid>/', UserBankApiSetView.as_view()),
    # path('bank/', BankApiSetView.as_view()),
    path('topup', TopUpFromStripe.as_view(), name = 'fiat_topup'),
    path('confirm_topup', ConfirmTopUpTransaction.as_view(), name = 'fiat_confirm_topup'),
    # path('confirmtopup/<int:userbalancehistoryid>/', ConfirmUserTopUp.as_view()),
    path('transfer/', TransferMoney.as_view())
]