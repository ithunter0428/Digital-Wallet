from django.contrib import admin
from crypto.models import UserCryptoAPIKey

# Register your models here.
admin.site.register(UserCryptoAPIKey)
