from django.contrib import admin
from django.urls import path, include
from rest_framework.authtoken.views import obtain_auth_token
from wallet.viewsactivity import RegisterUserAPIView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('register', RegisterUserAPIView.as_view()),
    path('auth/', obtain_auth_token),
    path('wallet/', include('wallet.urls')),
    path('payments/', include('payments.urls')),
]
