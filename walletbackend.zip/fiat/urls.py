from django.urls import path, include
from .views import GetBalance, UserRequestTopUp, ConfirmUserTopUp, UserTransferMoney, UserBankApiSetView, BankApiSetView

urlpatterns = [
    path('get_balance', GetBalance.as_view()),
    # path('bankuser/<int:userid>/', UserBankApiSetView.as_view()),
    # path('bank/', BankApiSetView.as_view()),
    # path('topup/', UserRequestTopUp.as_view()),
    # path('confirmtopup/<int:userbalancehistoryid>/', ConfirmUserTopUp.as_view()),
    # path('transfer/', UserTransferMoney.as_view())
]